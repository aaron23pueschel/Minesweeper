static int date_from_ISO8601 (const char *text, time_t * value) {
    n = 10;
    tm.tm_mon = 0;
    for(i = 0; i < 2; i++) {
      XMLRPC_IS_NUMBER(text[i+4])
       tm.tm_mon += (text[i+4]-'0')*n;
       n /= 10;
    }
    tm.tm_mon --;
   if(tm.tm_mon < 0 || tm.tm_mon > 11) {
       return -1;
   }
 
    n = 10;
    tm.tm_mday = 0;
    for(i = 0; i < 2; i++) {
      XMLRPC_IS_NUMBER(text[i+6])
       tm.tm_mday += (text[i+6]-'0')*n;
       n /= 10;
    }