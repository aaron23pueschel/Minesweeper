 void ide_data_writew(void *opaque, uint32_t addr, uint32_t val)
 {
    IDEBus *bus = opaque;
    IDEState *s = idebus_active_if(bus);
    uint8_t *p;
 
      /* PIO data access allowed only when DRQ bit is set. The result of a write
       * during PIO out is indeterminate, just ignore it. */
      if (!(s->status & DRQ_STAT) || ide_is_pio_out(s)) {
          return;
      }
  
      p = s->data_ptr;
	  if (p + 2 > s->data_end) {						//FIX HERE
        return;
    }
      *(uint16_t *)p = le16_to_cpu(val);
      p += 2;
      s->data_ptr = p;
      if (p >= s->data_end)
          s->end_transfer_func(s);
  }
  
  uint32_t ide_data_readw(void *opaque, uint32_t addr)
  {
      IDEBus *bus = opaque;
      IDEState *s = idebus_active_if(bus);
      uint8_t *p;
      int ret;
  
      /* PIO data access allowed only when DRQ bit is set. The result of a read
       * during PIO in is indeterminate, return 0 and don't move forward. */
      if (!(s->status & DRQ_STAT) || !ide_is_pio_out(s)) {
          return 0;
      }
  
      p = s->data_ptr;
	  if (p + 2 > s->data_end) {				//FIX HERE
        return 0;
    }
      ret = cpu_to_le16(*(uint16_t *)p);
      p += 2;
      s->data_ptr = p;
     if (p >= s->data_end)
          s->end_transfer_func(s);
      return ret;
  }
  
  void ide_data_writel(void *opaque, uint32_t addr, uint32_t val)
  {
      IDEBus *bus = opaque;
      IDEState *s = idebus_active_if(bus);
      uint8_t *p;
  
      /* PIO data access allowed only when DRQ bit is set. The result of a write
       * during PIO out is indeterminate, just ignore it. */
      if (!(s->status & DRQ_STAT) || ide_is_pio_out(s)) {
          return;
      }
  
      p = s->data_ptr;
	  if (p + 4 > s->data_end) {					//FIX HERE
        return;
    }
      *(uint32_t *)p = le32_to_cpu(val);
      p += 4;
      s->data_ptr = p;
      if (p >= s->data_end)
          s->end_transfer_func(s);
  }
  
  uint32_t ide_data_readl(void *opaque, uint32_t addr)
  {
      IDEBus *bus = opaque;
      IDEState *s = idebus_active_if(bus);
      uint8_t *p;
      int ret;
  
      /* PIO data access allowed only when DRQ bit is set. The result of a read
       * during PIO in is indeterminate, return 0 and don't move forward. */
      if (!(s->status & DRQ_STAT) || !ide_is_pio_out(s)) {
          return 0;
      }
  
      p = s->data_ptr;
	  if (p + 4 > s->data_end) {					//FIX HERE
        return 0;
    }
      ret = cpu_to_le32(*(uint32_t *)p);
      p += 4;
      s->data_ptr = p;
      if (p >= s->data_end)
          s->end_transfer_func(s);
      return ret;
  }