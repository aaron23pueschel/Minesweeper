static void zend_ini_do_op(char type, zval *result, zval *op1, zval *op2)
   {
           int i_result;
           int i_op1, i_op2;
           char str_result[MAX_LENGTH_OF_LONG+1];				//FIX HERE
   
           i_op1 = atoi(Z_STRVAL_P(op1));
           free(Z_STRVAL_P(op1));
           if (op2) {
                   i_op2 = atoi(Z_STRVAL_P(op2));
                   free(Z_STRVAL_P(op2));
           } else {
                   i_op2 = 0;
           }
   
           switch (type) {
                   case '|':
                           i_result = i_op1 | i_op2;
                           break;
                   case '&':
                           i_result = i_op1 & i_op2;
                           break;
                   case '^':
                           i_result = i_op1 ^ i_op2;
                           break;
                   case '~':
                           i_result = ~i_op1;
                           break;
                   case '!':
                           i_result = !i_op1;
                           break;
                   default:
                           i_result = 0;
                           break;
           }
  
           Z_STRLEN_P(result) = zend_sprintf(str_result, "%d", i_result);
           Z_STRVAL_P(result) = (char *) malloc(Z_STRLEN_P(result)+1);
           memcpy(Z_STRVAL_P(result), str_result, Z_STRLEN_P(result));
         Z_STRVAL_P(result)[Z_STRLEN_P(result)] = 0;
           Z_TYPE_P(result) = IS_STRING;
   }