dissect_ber_GeneralizedTime(gboolean implicit_tag, asn1_ctx_t *actx, proto_tree *tree, tvbuff_t *tvb, int offset, gint hf_id)
 {
    char          str[35];
    int           tmp_int;
    const guint8 *tmpstr;
    char         *strptr;
     char          first_delim[2];
     int           first_digits;
     char          second_delim[2];
     int           second_digits;
     int           ret;
    gint8         ber_class;
     gboolean      pc;
     gint        tag;
     int           identifier_offset;
    int           identifier_len;
     guint       len;
     int           len_offset;
     int           len_len;
     int           end_offset;
     int           hoffset;
     proto_item   *cause;
 
    if (!implicit_tag) {
         hoffset = offset;
         identifier_offset = offset;
         offset = dissect_ber_identifier(actx->pinfo, tree, tvb, offset, &ber_class, &pc, &tag);
         identifier_len = offset - identifier_offset;
         len_offset = offset;
         offset = dissect_ber_length(actx->pinfo, tree, tvb, offset, &len, NULL);
         len_len = offset - len_offset;
         end_offset = offset+len;
 
         /* sanity check. we only handle universal/generalized time */
       if ( (ber_class != BER_CLASS_UNI)
           || (tag != BER_UNI_TAG_GeneralizedTime)) {
             tvb_ensure_bytes_exist(tvb, hoffset, 2);
             cause = proto_tree_add_expert_format(
               tree, actx->pinfo, &ei_ber_expected_generalized_time,
               tvb, identifier_offset, identifier_len,
               "BER Error: GeneralizedTime expected but class:%s(%d) %s tag:%d was unexpected",
                 val_to_str_const(ber_class, ber_class_codes, "Unknown"),
                 ber_class,
                 pc ? ber_pc_codes_short.true_string : ber_pc_codes_short.false_string,
                 tag);
             if (decode_unexpected) {
                 proto_tree *unknown_tree = proto_item_add_subtree(cause, ett_ber_unknown);
                 dissect_unknown_ber(actx->pinfo, tvb, hoffset, unknown_tree);
             }
             return end_offset;
         }
     } else {
         len = tvb_reported_length_remaining(tvb, offset);
         len_offset = 0;
         len_len = 0;
         end_offset = offset+len;
     }
 
     if ((len < 14) || (len > 23)) {
         cause = proto_tree_add_expert_format(
             tree, actx->pinfo, &ei_ber_error_length,
             tvb, len_offset, len_len,
             "BER Error: GeneralizedTime invalid length: %u",
             len);
         if (decode_unexpected) {
             proto_tree *unknown_tree = proto_item_add_subtree(cause, ett_ber_unknown);
             dissect_unknown_ber(actx->pinfo, tvb, offset, unknown_tree);
         }
         return end_offset;
     }
 
     tmpstr = tvb_get_string_enc(wmem_packet_scope(), tvb, offset, len, ENC_ASCII);
     strptr = str;
     /* those fields are allways present */
     strptr += g_snprintf(str, 20, "%.4s-%.2s-%.2s %.2s:%.2s:%.2s",
                          tmpstr, tmpstr+4, tmpstr+6, tmpstr+8,
                          tmpstr+10, tmpstr+12);

     first_delim[0]  = 0;
     second_delim[0] = 0;
     ret = sscanf(tmpstr, "%14d%1[.,+-Z]%4d%1[+-Z]%4d", &tmp_int, first_delim, &first_digits, second_delim, &second_digits);	
     /* tmp_int does not contain valid value because of overflow but we use it just for format checking */
     if (ret < 1) {
         /* Nothing matched */
         goto invalid;
     }
 
     if (ret >= 2) {
         /*
          * We saw the date+time and the first delimiter.
          *
          * Either:
          *
          *    it's '.' or ',', in which case we have a fraction of a
          *    minute or hour;
          *
          *    it's '+' or '-', in which case we have an offset from UTC;
          *
          *    it's 'Z', in which case the time is UTC.
          */
         switch (first_delim[0]) {
         case '.':
         case ',':
             /*
              * Fraction of a minute or an hour.
              */
             if (ret == 2 ) {																					//BUG HERE
                 /*
                  * We saw the decimal sign, but didn't see the fraction
                  * or
                  * we got a number outside the valid range.
                  */
                goto invalid;
             }
             strptr += g_snprintf(strptr, 5, "%c%.3d", first_delim[0], first_digits);
             if (ret >= 4) {
                 /*
                  * We saw the fraction and the second delimiter.
                  *
                  * Either:
                  *
                  *    it's '+' or '-', in which case we have an offset
                  *    from UTC;
                  *
                  *    it's 'Z', in which case the time is UTC.
                  */
                 switch (second_delim[0]) {
                 case '+':
                 case '-':
                     if (ret == 4) {
                         /*
                          * We saw the + or -, but didn't see the offset
                          * from UTC.
                          */
                       goto invalid;
                     }
                     g_snprintf(strptr, 12, " (UTC%c%.4d)", second_delim[0], second_digits);
                     break;
               case 'Z':
                    g_snprintf(strptr, 7, " (UTC)");
                   break;
                 default:
                     /* handle the malformed field */
                     break;
                }
             }
             break;
         case '+':
         case '-':
             /*
              * Offset from UTC.
              */
             if (ret == 2) {
                 /*
                  * We saw the + or -1, but didn't see the offset.
                  */
                 goto invalid;
             }
             g_snprintf(strptr, 12, " (UTC%c%.4d)", first_delim[0], first_digits);
             break;
         case 'Z':
             g_snprintf(strptr, 7, " (UTC)");
             break;
         default:
             /* handle the malformed field */
             break;
         }
     }
 
     if (hf_id >= 0) {
         proto_tree_add_string(tree, hf_id, tvb, offset, len, str);
    }
 
     offset+=len;
     return offset;
 
 invalid:
     cause = proto_tree_add_expert_format(
         tree, actx->pinfo, &ei_ber_invalid_format_generalized_time,
         tvb, offset, len,
         "BER Error: GeneralizedTime invalid format: %s",
         tmpstr);
     if (decode_unexpected) {
         proto_tree *unknown_tree = proto_item_add_subtree(cause, ett_ber_unknown);
         dissect_unknown_ber(actx->pinfo, tvb, offset, unknown_tree);
     }
     return end_offset;
 }