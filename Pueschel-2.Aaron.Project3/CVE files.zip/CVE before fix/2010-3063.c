php_mysqlnd_read_error_from_line(zend_uchar *buf, size_t buf_len,
	                                                                char *error, int error_buf_len,
	                                                                unsigned int *error_no, char *sqlstate TSRMLS_DC)
	{
	        zend_uchar *p = buf;
	        int error_msg_len= 0;
	
	        DBG_ENTER("php_mysqlnd_read_error_from_line");
	
	        
	
	        if (buf_len > 2) {
	                *error_no = uint2korr(p);
	                p+= 2;
	                /*
	                  sqlstate is following. No need to check for buf_left_len as we checked > 2 above,
	                  if it was >=2 then we would need a check
	                */
	                if (*p == '#') {
	                         memcpy(sqlstate, ++p, MYSQLND_SQLSTATE_LENGTH);	                  	//BUG HERE    
                        p+= MYSQLND_SQLSTATE_LENGTH;
	                }
					error_msg_len = buf_len - (p - buf);	 
                 error_msg_len = MIN(error_msg_len, error_buf_len - 1);	 
                 memcpy(error, p, error_msg_len);	 
         } else {	 
                 *error_no = CR_UNKNOWN_ERROR;	 
                 memcpy(sqlstate, unknown_sqlstate, MYSQLND_SQLSTATE_LENGTH);								//BUG HERE
	        }

       sqlstate[MYSQLND_SQLSTATE_LENGTH] = '\0';
	        error[error_msg_len]= '\0';

       DBG_RETURN(FAIL);
	}