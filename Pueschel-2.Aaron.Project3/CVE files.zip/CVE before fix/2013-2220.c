int
rad_get_vendor_attr(u_int32_t *vendor, const void **data, size_t *len)									//BUG HERE
rad_get_vendor_attr(u_int32_t *vendor, unsigned char *type, const void **data, size_t *len, const void *raw, size_t raw_len) //FIX HERE
{
	struct vendor_attribute *attr;

	attr = (struct vendor_attribute *)*data;															//BUG HERE
							
	*vendor = ntohl(attr->vendor_value);
	
	*data = attr->attrib_data;
	*len = attr->attrib_len - 2;

	

	return (attr->attrib_type);
}