 ssize_t pcnet_receive(NetClientState *nc, const uint8_t *buf, size_t size_)
  {
      PCNetState *s = qemu_get_nic_opaque(nc);
      int is_padr = 0, is_bcast = 0, is_ladr = 0;
      uint8_t buf1[60];
      int remaining;
      int crc_err = 0;
      int size = size_;																		//BUG HERE
  
      if (CSR_DRX(s) || CSR_STOP(s) || CSR_SPND(s) || !size ||
          (CSR_LOOP(s) && !s->looptest)) {
          return -1;
      }
  #ifdef PCNET_DEBUG
      printf("pcnet_receive size=%d\n", size);												//BUG HERE									
  #endif