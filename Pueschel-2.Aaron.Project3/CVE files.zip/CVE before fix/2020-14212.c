DNNModel *ff_dnn_load_model_native(const char *model_filename)
  {
      DNNModel *model = NULL;
      char header_expected[] = "FFMPEGDNNNATIVE";
      char *buf;
      size_t size;
      int version, header_size, major_version_expected = 1;
      ConvolutionalNetwork *network = NULL;
      AVIOContext *model_file_context;
      int file_size, dnn_size, parsed_size;
      int32_t layer;
      DNNLayerType layer_type;
  
      if (avio_open(&model_file_context, model_filename, AVIO_FLAG_READ) < 0){
          return NULL;
      }
      file_size = avio_size(model_file_context);
  
      model = av_mallocz(sizeof(DNNModel));
      if (!model){
          goto fail;
      }
  
      /**
       * check file header with string and version
       */
      size = sizeof(header_expected);
      buf = av_malloc(size);
      if (!buf) {
          goto fail;
      }
  
     // size - 1 to skip the ending '\0' which is not saved in file
      avio_get_str(model_file_context, size - 1, buf, size);
      dnn_size = size - 1;
      if (strncmp(buf, header_expected, size) != 0) {
          av_freep(&buf);
        goto fail;
     }
     av_freep(&buf);
  
    version = (int32_t)avio_rl32(model_file_context);
      dnn_size += 4;
      if (version != major_version_expected) {
          goto fail;
      }
  
      // currently no need to check minor version
      version = (int32_t)avio_rl32(model_file_context);
      dnn_size += 4;
     header_size = dnn_size;
 
      network = av_mallocz(sizeof(ConvolutionalNetwork));
  if (!network){
         goto fail;
      }
     model->model = (void *)network;
 
      avio_seek(model_file_context, file_size - 8, SEEK_SET);
     network->layers_num = (int32_t)avio_rl32(model_file_context);
     network->operands_num = (int32_t)avio_rl32(model_file_context);
      dnn_size += 8;
     avio_seek(model_file_context, header_size, SEEK_SET);
  
      network->layers = av_mallocz(network->layers_num * sizeof(Layer));
     if (!network->layers){
          goto fail;
      }
  
      network->operands = av_mallocz(network->operands_num * sizeof(DnnOperand));
      if (!network->operands){
          goto fail;
      }
  
      for (layer = 0; layer < network->layers_num; ++layer){
          layer_type = (int32_t)avio_rl32(model_file_context);
          dnn_size += 4;
  
         if (layer_type >= DLT_COUNT) {
              goto fail;
         }
 
         network->layers[layer].type = layer_type;
         parsed_size = layer_funcs[layer_type].pf_load(&network->layers[layer], model_file_context, file_size);
          if (!parsed_size) {
             goto fail;
          }
         dnn_size += parsed_size;
      }
 
     for (int32_t i = 0; i < network->operands_num; ++i){
          DnnOperand *oprd;
         int32_t name_len;
         int32_t operand_index = (int32_t)avio_rl32(model_file_context);
          dnn_size += 4;
  
          oprd = &network->operands[operand_index];									//BUG HERE
          name_len = (int32_t)avio_rl32(model_file_context);
          dnn_size += 4;
  
          avio_get_str(model_file_context, name_len, oprd->name, sizeof(oprd->name));
          dnn_size += name_len;
  
          oprd->type = (int32_t)avio_rl32(model_file_context);
          dnn_size += 4;
  
          oprd->data_type = (int32_t)avio_rl32(model_file_context);
          dnn_size += 4;
  
          for (int32_t dim = 0; dim < 4; ++dim) {
              oprd->dims[dim] = (int32_t)avio_rl32(model_file_context);
            dnn_size += 4;
         }
  
          oprd->isNHWC = 1;
      }
  
      avio_closep(&model_file_context);
  
      if (dnn_size != file_size){
          ff_dnn_free_model_native(&model);
          return NULL;
      }
  
      model->set_input_output = &set_input_output_native;
      model->get_input = &get_input_native;
  
      return model;
  
  fail:
      ff_dnn_free_model_native(&model);
      avio_closep(&model_file_context);
      return NULL;
  }