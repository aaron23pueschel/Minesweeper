size_t php_mysqlnd_auth_write(void *_packet, MYSQLND * conn TSRMLS_DC)
	{
	        char buffer[1024];																	//BUG HERE
	        register char *p= buffer + MYSQLND_HEADER_SIZE; /* start after the header */
	        int len;
	        register MYSQLND_PACKET_AUTH *packet= (MYSQLND_PACKET_AUTH *) _packet;
	
	        DBG_ENTER("php_mysqlnd_auth_write");
	
	        packet->client_flags |= MYSQLND_CAPABILITIES;
	
	        if (packet->db) {
	                packet->client_flags |= CLIENT_CONNECT_WITH_DB;
	        }
	
	        if (PG(open_basedir) && strlen(PG(open_basedir))) {
                packet->client_flags ^= CLIENT_LOCAL_FILES;
	        }
	
	        int4store(p, packet->client_flags);
	        p+= 4;
	
	        int4store(p, packet->max_packet_size);
	        p+= 4;
	
	        int1store(p, packet->charset_no);
	        p++;
	
	        memset(p, 0, 23); /* filler */
	        p+= 23;
	
	        if (!packet->send_half_packet) {
	                len = strlen(packet->user);															//BUG HERE
	                p+= len;
	                *p++ = '\0';
	
	                /* copy scrambled pass*/
	                if (packet->password && packet->password[0]) {
	                        /* In 4.1 we use CLIENT_SECURE_CONNECTION and thus the len of the buf should be passed */
	                        int1store(p, 20);															//BUG HERE
	                        p++;
	                        php_mysqlnd_scramble((zend_uchar*)p, packet->server_scramble_buf, (zend_uchar*)packet->password);
	                        p+= 20;																		//BUG HERE
	                } else {
	                        /* Zero length */
	                        int1store(p, 0);
	                        p++;
	                }
	
	                if (packet->db) {
	                        memcpy(p, packet->db, packet->db_len);										//BUG HERE
							p+= packet->db_len;
	                        *p++= '\0';
	                }
	                /* Handle CLIENT_CONNECT_WITH_DB */
             /* no \0 for no DB */
	        }
	
	        DBG_RETURN(conn->net->m.send(conn, buffer, p - buffer - MYSQLND_HEADER_SIZE TSRMLS_CC));
	}