CWD_API int virtual_file_ex(cwd_state *state, const char *path, verify_path_func verify_path, int use_realpath TSRMLS_DC) /* {{{ */
 {
         int path_length = strlen(path);
         char resolved_path[MAXPATHLEN];
         int start = 1;
         int ll = 0;
         time_t t;
         int ret;
         int add_slash;
        void *tmp;
 
         if (path_length == 0 || path_length >= MAXPATHLEN-1) {				//BUG HERE
 #ifdef TSRM_WIN32
# if _MSC_VER < 1300
                 errno = EINVAL;
 # else
                 _set_errno(EINVAL);
 # endif
 #else
                 errno = EINVAL;
 #endif
                 return 1;
         }