static bfd_boolean
 process_mips_specific (Filedata * filedata)
 {
   Elf_Internal_Dyn * entry;
   Elf_Internal_Shdr *sect = NULL;
   size_t liblist_offset = 0;
   size_t liblistno = 0;
   size_t conflictsno = 0;
   size_t options_offset = 0;
   size_t conflicts_offset = 0;
   size_t pltrelsz = 0;
   size_t pltrel = 0;
   bfd_vma pltgot = 0;
   bfd_vma mips_pltgot = 0;
   bfd_vma jmprel = 0;
   bfd_vma local_gotno = 0;
   bfd_vma gotsym = 0;
   bfd_vma symtabno = 0;
   bfd_boolean res = TRUE;
 
   if (! process_attributes (filedata, NULL, SHT_GNU_ATTRIBUTES, NULL,
                             display_mips_gnu_attribute))
     res = FALSE;
 
   sect = find_section (filedata, ".MIPS.abiflags");
 
   if (sect != NULL)
     {
       Elf_External_ABIFlags_v0 *abiflags_ext;
       Elf_Internal_ABIFlags_v0 abiflags_in;

       if (sizeof (Elf_External_ABIFlags_v0) != sect->sh_size)
         {
           error (_("Corrupt MIPS ABI Flags section.\n"));
           res = FALSE;
         }
       else
         {
          abiflags_ext = get_data (NULL, filedata, sect->sh_offset, 1,
                                    sect->sh_size, _("MIPS ABI Flags section"));
           if (abiflags_ext)
             {
               abiflags_in.version = BYTE_GET (abiflags_ext->version);
               abiflags_in.isa_level = BYTE_GET (abiflags_ext->isa_level);
               abiflags_in.isa_rev = BYTE_GET (abiflags_ext->isa_rev);
              abiflags_in.gpr_size = BYTE_GET (abiflags_ext->gpr_size);
               abiflags_in.cpr1_size = BYTE_GET (abiflags_ext->cpr1_size);
               abiflags_in.cpr2_size = BYTE_GET (abiflags_ext->cpr2_size);
              abiflags_in.fp_abi = BYTE_GET (abiflags_ext->fp_abi);
               abiflags_in.isa_ext = BYTE_GET (abiflags_ext->isa_ext);
               abiflags_in.ases = BYTE_GET (abiflags_ext->ases);
             abiflags_in.flags1 = BYTE_GET (abiflags_ext->flags1);
               abiflags_in.flags2 = BYTE_GET (abiflags_ext->flags2);
 
               printf ("\nMIPS ABI Flags Version: %d\n", abiflags_in.version);
               printf ("\nISA: MIPS%d", abiflags_in.isa_level);
             if (abiflags_in.isa_rev > 1)
                 printf ("r%d", abiflags_in.isa_rev);
              printf ("\nGPR size: %d",
                       get_mips_reg_size (abiflags_in.gpr_size));
               printf ("\nCPR1 size: %d",
                       get_mips_reg_size (abiflags_in.cpr1_size));
               printf ("\nCPR2 size: %d",
                      get_mips_reg_size (abiflags_in.cpr2_size));
               fputs ("\nFP ABI: ", stdout);
               print_mips_fp_abi_value (abiflags_in.fp_abi);
               fputs ("ISA Extension: ", stdout);
               print_mips_isa_ext (abiflags_in.isa_ext);
               fputs ("\nASEs:", stdout);
               print_mips_ases (abiflags_in.ases);
               printf ("\nFLAGS 1: %8.8lx", abiflags_in.flags1);
               printf ("\nFLAGS 2: %8.8lx", abiflags_in.flags2);
               fputc ('\n', stdout);
               free (abiflags_ext);
             }
         }
     }
 
   /* We have a lot of special sections.  Thanks SGI!  */
   if (dynamic_section == NULL)
     {
       /* No dynamic information available.  See if there is static GOT.  */
       sect = find_section (filedata, ".got");
       if (sect != NULL)
         {
           unsigned char *data_end;
           unsigned char *data;
           bfd_vma ent, end;
           int addr_size;
 
           pltgot = sect->sh_addr;
 
           ent = pltgot;
           addr_size = (is_32bit_elf ? 4 : 8);
           end = pltgot + sect->sh_size;
 
           data = (unsigned char *) get_data (NULL, filedata, sect->sh_offset,
                                              end - pltgot, 1,
                                              _("Global Offset Table data"));
           /* PR 855: Null data is handled gracefully throughout.  */
           data_end = data + (end - pltgot);

           printf (_("\nStatic GOT:\n"));
           printf (_(" Canonical gp value: "));
           print_vma (ent + 0x7ff0, LONG_HEX);
           printf ("\n\n");
 
           /* In a dynamic binary GOT[0] is reserved for the dynamic
              loader to store the lazy resolver pointer, however in
              a static binary it may well have been omitted and GOT
              reduced to a table of addresses.
              PR 4: Check for the entry being fully available
              before fetching it.  */
           if (data
               && data + ent - pltgot + addr_size <= data_end
               && byte_get (data + ent - pltgot, addr_size) == 0)
             {
               printf (_(" Reserved entries:\n"));
               printf (_("  %*s %10s %*s\n"),
                       addr_size * 2, _("Address"), _("Access"),
                       addr_size * 2, _("Value"));
               ent = print_mips_got_entry (data, pltgot, ent, data_end);
               printf ("\n");
               if (ent == (bfd_vma) -1)
                 goto sgot_print_fail;
 
               /* Check for the MSB of GOT[1] being set, identifying a
                  GNU object.  This entry will be used by some runtime
                  loaders, to store the module pointer.  Otherwise this
                  is an ordinary local entry.
                  PR 4: Check for the entry being fully available
                  before fetching it.  */
               if (data
                   && data + ent - pltgot + addr_size <= data_end
                   && (byte_get (data + ent - pltgot, addr_size)
                       >> (addr_size * 8 - 1)) != 0)
                 {
                   ent = print_mips_got_entry (data, pltgot, ent, data_end);
                   printf ("\n");
                   if (ent == (bfd_vma) -1)
                     goto sgot_print_fail;
                 }
               printf ("\n");
             }
 
           if (data != NULL && ent < end)
             {
               printf (_(" Local entries:\n"));
               printf ("  %*s %10s %*s\n",
                      addr_size * 2, _("Address"), _("Access"),
                       addr_size * 2, _("Value"));
               while (ent < end)
                 {
                   ent = print_mips_got_entry (data, pltgot, ent, data_end);
                  printf ("\n");
                   if (ent == (bfd_vma) -1)
                     goto sgot_print_fail;
                 }
               printf ("\n");
             }

         sgot_print_fail:
           if (data)
             free (data);
         }
       return res;
     }

   for (entry = dynamic_section;
       /* PR 531 file: 0-50589-0.004.  */
       entry < dynamic_section + dynamic_nent && entry->d_tag != DT_NULL;
       ++entry)
     switch (entry->d_tag)
       {
       case DT_MIPS_LIBLIST:
         liblist_offset
           = offset_from_vma (filedata, entry->d_un.d_val,
                              liblistno * sizeof (Elf32_External_Lib));
         break;
       case DT_MIPS_LIBLISTNO:
         liblistno = entry->d_un.d_val;
        break;
       case DT_MIPS_OPTIONS:
         options_offset = offset_from_vma (filedata, entry->d_un.d_val, 0);
        break;
       case DT_MIPS_CONFLICT:
         conflicts_offset
           = offset_from_vma (filedata, entry->d_un.d_val,
                             conflictsno * sizeof (Elf32_External_Conflict));
         break;
       case DT_MIPS_CONFLICTNO:
         conflictsno = entry->d_un.d_val;
         break;
       case DT_PLTGOT:
        pltgot = entry->d_un.d_ptr;
         break;
       case DT_MIPS_LOCAL_GOTNO:
         local_gotno = entry->d_un.d_val;
         break;
      case DT_MIPS_GOTSYM:
         gotsym = entry->d_un.d_val;
         break;
       case DT_MIPS_SYMTABNO:
        symtabno = entry->d_un.d_val;
      break;
      case DT_MIPS_PLTGOT:
         mips_pltgot = entry->d_un.d_ptr;
         break;
       case DT_PLTREL:
         pltrel = entry->d_un.d_val;
        break;
       case DT_PLTRELSZ:
         pltrelsz = entry->d_un.d_val;
         break;
      case DT_JMPREL:
         jmprel = entry->d_un.d_ptr;
         break;
       default:
         break;
       }
 
   if (liblist_offset != 0 && liblistno != 0 && do_dynamic)
     {
      Elf32_External_Lib * elib;
       size_t cnt;
 
       elib = (Elf32_External_Lib *) get_data (NULL, filedata, liblist_offset,
                                               liblistno,
                                               sizeof (Elf32_External_Lib),
                                               _("liblist section data"));
       if (elib)
         {
           printf (ngettext ("\nSection '.liblist' contains %lu entry:\n",
                             "\nSection '.liblist' contains %lu entries:\n",
                            (unsigned long) liblistno),
                   (unsigned long) liblistno);
          fputs (_("     Library              Time Stamp          Checksum   Version Flags\n"),
                 stdout);
 
           for (cnt = 0; cnt < liblistno; ++cnt)
             {
               Elf32_Lib liblist;
               time_t atime;
               char timebuf[8];
             struct tm * tmp;
              liblist.l_name = BYTE_GET (elib[cnt].l_name);
            atime = BYTE_GET (elib[cnt].l_time_stamp);
             liblist.l_checksum = BYTE_GET (elib[cnt].l_checksum);
               liblist.l_version = BYTE_GET (elib[cnt].l_version);
             liblist.l_flags = BYTE_GET (elib[cnt].l_flags);
              tmp = gmtime (&atime);
             snprintf (timebuf, sizeof (timebuf),
                        "%04u-%02u-%02uT%02u:%02u:%02u",
                       tmp->tm_year + 00, tmp->tm_mon + 1, tmp->tm_mday,
                       tmp->tm_hour, tmp->tm_min, tmp->tm_sec);
              printf ("%3lu: ", (unsigned long) cnt);
               if (VALID_DYNAMIC_NAME (liblist.l_name))
                 print_symbol (, GET_DYNAMIC_NAME (liblist.l_name));
               else
                 printf (_("<corrupt: %9ld>"), liblist.l_name);
               printf (" %s %#10lx %-7ld", timebuf, liblist.l_checksum,
                      liblist.l_version);
 
               if (liblist.l_flags == 0)
                 puts (_(" NONE"));
               else
                 {
                   static const struct
                   {
                     const char * name;
                     int bit;
                  }
                   l_flags_vals[] =
                   {
                     { " EXACT_MATCH", LL_EXACT_MATCH },
                     { " IGNORE_INT_VER", LL_IGNORE_INT_VER },
                     { " REQUIRE_MINOR", LL_REQUIRE_MINOR },
                     { " EXPORTS", LL_EXPORTS },
                     { " DELAY_LOAD", LL_DELAY_LOAD },
                     { " DELTA", LL_DELTA }
                   };
                  int flags = liblist.l_flags;
                   size_t fcnt;
 
                   for (fcnt = 0; fcnt < ARRAY_SIZE (l_flags_vals); ++fcnt)
                     if ((flags & l_flags_vals[fcnt].bit) != 0)
                       {
                         fputs (l_flags_vals[fcnt].name, stdout);
                         flags ^= l_flags_vals[fcnt].bit;
                       }
                   if (flags != 0)
                    printf (" %#x", (unsigned int) flags);
 
                   puts ("");
                 }
             }
 
          free (elib);
         }
       else
         res = FALSE;
    }
 
   if (options_offset != 0)
     {
       Elf_External_Options * eopt;
       Elf_Internal_Options * iopt;
       Elf_Internal_Options * option;
       size_t offset;
       int cnt;
       sect = filedata->section_headers;

       /* Find the section header so that we get the size.  */
      sect = find_section_by_type (filedata, SHT_MIPS_OPTIONS);
       /* PR 533 file: 0-277276-0.004.  */
       if (sect == NULL)
         {
           error (_("No MIPS_OPTIONS header found\n"));
           return FALSE;
        }
																									//BUG HERE
 
       eopt = (Elf_External_Options *) get_data (NULL, filedata, options_offset, ,
                                                 sect->sh_size, _("options"));
       if (eopt)
         {
          iopt = (Elf_Internal_Options *)
               cmalloc ((sect->sh_size / sizeof (eopt)), sizeof (* iopt));
           if (iopt == NULL)
             {
               error (_("Out of memory allocating space for MIPS options\n"));
               return FALSE;
             }
 
           offset = cnt = 0;
           option = iopt;
          while (offset <= sect->sh_size - sizeof (* eopt))
           {
             Elf_External_Options * eoption;
               eoption = (Elf_External_Options *) ((char *) eopt + offset);
              option->kind = BYTE_GET (eoption->kind);
             option->size = BYTE_GET (eoption->size);
             option->section = BYTE_GET (eoption->section);
              option->info = BYTE_GET (eoption->info);
              /* PR 531: file: ffa0fa3b.  */
             if (option->size < sizeof (* eopt)
                 || offset + option->size > sect->sh_size)
                 {
                   error (_("Invalid size (%u) for MIPS option\n"), option->size);
                   return FALSE;
                 }
               offset += option->size;

               ++option;
               ++cnt;
             }
 
           printf (ngettext ("\nSection '%s' contains %d entry:\n",
                             "\nSection '%s' contains %d entries:\n",
                             cnt),
                   printable_section_name (filedata, sect), cnt);
 
           option = iopt;
           offset = 0;
 
           while (cnt-- > 0)
             {
               size_t len;
 
              switch (option->kind)
                 {
                 case ODK_NULL:
                  /* This shouldn't happen.  */
                   printf (" NULL       %d %lx", option->section, option->info);
                  break;
                 case ODK_REGINFO:
                   printf (" REGINFO    ");
                   if (filedata->file_header.e_machine == EM_MIPS)
                     {
                       /* 32bit form.  */
                      Elf32_External_RegInfo * ereg;
                      Elf32_RegInfo reginfo;
                      ereg = (Elf32_External_RegInfo *) (option + 1);
                       reginfo.ri_gprmask = BYTE_GET (ereg->ri_gprmask);
                       reginfo.ri_cprmask[0] = BYTE_GET (ereg->ri_cprmask[0]);
                      reginfo.ri_cprmask[1] = BYTE_GET (ereg->ri_cprmask[1]);
                       reginfo.ri_cprmask[2] = BYTE_GET (ereg->ri_cprmask[2]);
                       reginfo.ri_cprmask[3] = BYTE_GET (ereg->ri_cprmask[3]);
                       reginfo.ri_gp_value = BYTE_GET (ereg->ri_gp_value);
 
                       printf ("GPR %08lx  GP 0x%lx\n",
                              reginfo.ri_gprmask,
                              (unsigned long) reginfo.ri_gp_value);
                       printf ("            CPR0 %08lx  CPR1 %08lx  CPR2 %08lx  CPR3 %08lx\n",
                               reginfo.ri_cprmask[0], reginfo.ri_cprmask[1],
                               reginfo.ri_cprmask[2], reginfo.ri_cprmask[3]);
                     }
                   else
                     {
                       /* 64 bit form.  */
                       Elf64_External_RegInfo * ereg;
                      Elf64_Internal_RegInfo reginfo;
 
                       ereg = (Elf64_External_RegInfo *) (option + 1);
                       reginfo.ri_gprmask    = BYTE_GET (ereg->ri_gprmask);
                       reginfo.ri_cprmask[0] = BYTE_GET (ereg->ri_cprmask[0]);
                       reginfo.ri_cprmask[1] = BYTE_GET (ereg->ri_cprmask[1]);
                       reginfo.ri_cprmask[2] = BYTE_GET (ereg->ri_cprmask[2]);
                       reginfo.ri_cprmask[3] = BYTE_GET (ereg->ri_cprmask[3]);
                       reginfo.ri_gp_value   = BYTE_GET (ereg->ri_gp_value);
 
                      printf ("GPR %08lx  GP 0x",
                               reginfo.ri_gprmask);
                       printf_vma (reginfo.ri_gp_value);
                       printf ("\n");
 
                       printf ("            CPR0 %08lx  CPR1 %08lx  CPR2 %08lx  CPR3 %08lx\n",
                               reginfo.ri_cprmask[0], reginfo.ri_cprmask[1],
                               reginfo.ri_cprmask[2], reginfo.ri_cprmask[3]);
                     }
                   ++option;
                  continue;
                 case ODK_EXCEPTIONS:
                   fputs (" EXCEPTIONS fpe_min(", stdout);
                   process_mips_fpe_exception (option->info & OEX_FPU_MIN);
                   fputs (") fpe_max(", stdout);
                   process_mips_fpe_exception ((option->info & OEX_FPU_MAX) >> 8);
                   fputs (")", stdout);
 
                   if (option->info & OEX_PAGE0)
                     fputs (" PAGE0", stdout);
                 if (option->info & OEX_SMM)
                   fputs (" SMM", stdout);
                 if (option->info & OEX_FPDBUG)
                   fputs (" FPDBUG", stdout);
               if (option->info & OEX_DISMISS)
                     fputs (" DISMISS", stdout);
                 break;
               case ODK_PAD:
                 fputs (" PAD       ", stdout);
                 if (option->info & OPAD_PREFIX)
                    fputs (" PREFIX", stdout);
                 if (option->info & OPAD_POSTFIX)
                   fputs (" POSTFIX", stdout);
                 if (option->info & OPAD_SYMBOL)
                    fputs (" SYMBOL", stdout);
                   break;
                 case ODK_HWPATCH:
                   fputs (" HWPATCH   ", stdout);
                   if (option->info & OHW_R4KEOP)
                     fputs (" R4KEOP", stdout);
                  if (option->info & OHW_R8KPFETCH)
                     fputs (" R8KPFETCH", stdout);
                   if (option->info & OHW_R5KEOP)
                     fputs (" R5KEOP", stdout);
                   if (option->info & OHW_R5KCVTL)
                     fputs (" R5KCVTL", stdout);
                   break;
                case ODK_FILL:
                   fputs (" FILL       ", stdout);
                   /* XXX Print content of info word?  */
                  break;
                 case ODK_TAGS:
                   fputs (" TAGS       ", stdout);
                   /* XXX Print content of info word?  */
                   break;
                 case ODK_HWAND:
                   fputs (" HWAND     ", stdout);
                   if (option->info & OHWA0_R4KEOP_CHECKED)
                     fputs (" R4KEOP_CHECKED", stdout);
                   if (option->info & OHWA0_R4KEOP_CLEAN)
                    fputs (" R4KEOP_CLEAN", stdout);
                   break;
                 case ODK_HWOR:
                   fputs (" HWOR      ", stdout);
                   if (option->info & OHWA0_R4KEOP_CHECKED)
                     fputs (" R4KEOP_CHECKED", stdout);
                   if (option->info & OHWA0_R4KEOP_CLEAN)
                     fputs (" R4KEOP_CLEAN", stdout);
                   break;
                case ODK_GP_GROUP:
               printf (" GP_GROUP  %#06lx  self-contained %#06lx",
                           option->info & OGP_GROUP,
                         (option->info & OGP_SELF) >> 16);
                  break;
                case ODK_IDENT:
               printf (" IDENT     %#06lx  self-contained %#06lx",
                          option->info & OGP_GROUP,
                          (option->info & OGP_SELF) >> 16);
                   break;
                default:
                /* This shouldn't happen.  */
               printf (" %3d ???     %d %lx",
                          option->kind, option->section, option->info);
                  break;
                }
              len = sizeof (* eopt);
               while (len < option->size)
                 {
                   unsigned char datum = * ((unsigned char *) eopt + offset + len);

                   if (ISPRINT (datum))
                     printf ("%c", datum);
                   else
                     printf ("\\%03o", datum);
                   len ++;
                 }
               fputs ("\n", stdout);
 
               offset += option->size;
               ++option;
        }
 
           free (eopt);
         }
       else
         res = FALSE;
     }

   if (conflicts_offset != 0 && conflictsno != 0)
    {
       Elf32_Conflict * iconf;
       size_t cnt;
 
       if (dynamic_symbols == NULL)
         {
           error (_("conflict list found without a dynamic symbol table\n"));
           return FALSE;
         }
 
      /* PR 5 - print a slightly more helpful error message
         if we are sure that the cmalloc will fail.  */
      if (conflictsno * sizeof (* iconf) > filedata->file_size)
        {
          error (_("Overlarge number of conflicts detected: %lx\n"),
                  (long) conflictsno);
          return FALSE;
        }

     iconf = (Elf32_Conflict *) cmalloc (conflictsno, sizeof (* iconf));
      if (iconf == NULL)
       {
         error (_("Out of memory allocating space for dynamic conflicts\n"));
         return FALSE;
     }
 
       if (is_32bit_elf)
         {
           Elf32_External_Conflict * econf32;
 
        econf32 = (Elf32_External_Conflict *)
               get_data (NULL, filedata, conflicts_offset, conflictsno,
                         sizeof (* econf32), _("conflict"));
           if (!econf32)
             return FALSE;
 
           for (cnt = 0; cnt < conflictsno; ++cnt)
             iconf[cnt] = BYTE_GET (econf32[cnt]);
 
           free (econf32);
       }
       else
         {
           Elf64_External_Conflict * econf64;
 
           econf64 = (Elf64_External_Conflict *)
               get_data (NULL, filedata, conflicts_offset, conflictsno,
                         sizeof (* econf64), _("conflict"));
           if (!econf64)
             return FALSE;
           for (cnt = 0; cnt < conflictsno; ++cnt)
            iconf[cnt] = BYTE_GET (econf64[cnt]);
 
           free (econf64);
         }
 
       printf (ngettext ("\nSection '.conflict' contains %lu entry:\n",
                         "\nSection '.conflict' contains %lu entries:\n",
                         (unsigned long) conflictsno),
              (unsigned long) conflictsno);
       puts (_("  Num:    Index       Value  Name"));
 
       for (cnt = 0; cnt < conflictsno; ++cnt)
         {
           printf ("%5lu: %8lu  ", (unsigned long) cnt, iconf[cnt]);
 
           if (iconf[cnt] >= num_dynamic_syms)
             printf (_("<corrupt symbol index>"));
           else
            {
               Elf_Internal_Sym * psym;
 
              psym = & dynamic_symbols[iconf[cnt]];
               print_vma (psym->st_value, FULL_HEX);
             putchar (' ');
               if (VALID_DYNAMIC_NAME (psym->st_name))
                 print_symbol (, GET_DYNAMIC_NAME (psym->st_name));
               else
              printf (_("<corrupt: %ld>"), psym->st_name);
            }
           putchar ('\n');
      }
       free (iconf);
     }
 
   if (pltgot != 0 && local_gotno != 0)
     {
      bfd_vma ent, local_end, global_end;
      size_t i, offset;
       unsigned char * data;
       unsigned char * data_end;
       int addr_size;
 
       ent = pltgot;
       addr_size = (is_32bit_elf ? 4 : 8);
       local_end = pltgot + local_gotno * addr_size;
 
       /* PR binutils/533 file: 0-27-0.004  */
      if (symtabno < gotsym)
         {
           error (_("The GOT symbol offset (%lu) is greater than the symbol table size (%lu)\n"),
                  (unsigned long) gotsym, (unsigned long) symtabno);
           return FALSE;
         }
 
      global_end = local_end + (symtabno - gotsym) * addr_size;
       /* PR 531: file: 54c91a34.  */
       if (global_end < local_end)
       {
         error (_("Too many GOT symbols: %lu\n"), (unsigned long) symtabno);
         return FALSE;
       }
       offset = offset_from_vma (filedata, pltgot, global_end - pltgot);
     data = (unsigned char *) get_data (NULL, filedata, offset,
                                        global_end - pltgot, 1,
                                        _("Global Offset Table data"));
     /* PR 855: Null data is handled gracefully throughout.  */
      data_end = data + (global_end - pltgot);
     printf (_("\nPrimary GOT:\n"));
     printf (_(" Canonical gp value: "));
     print_vma (pltgot + 0x7ff0, LONG_HEX);
       printf ("\n\n");
 
       printf (_(" Reserved entries:\n"));
       printf (_("  %*s %10s %*s Purpose\n"),
               addr_size * 2, _("Address"), _("Access"),
              addr_size * 2, _("Initial"));
       ent = print_mips_got_entry (data, pltgot, ent, data_end);
       printf (_(" Lazy resolver\n"));
       if (ent == (bfd_vma) -1)
         goto got_print_fail;
 
     /* Check for the MSB of GOT[1] being set, denoting a GNU object.
          This entry will be used by some runtime loaders, to store the
          module pointer.  Otherwise this is an ordinary local entry.
          PR 4: Check for the entry being fully available before
         fetching it.  */
       if (data
           && data + ent - pltgot + addr_size <= data_end
           && (byte_get (data + ent - pltgot, addr_size)
               >> (addr_size * 8 - 1)) != 0)
         {
           ent = print_mips_got_entry (data, pltgot, ent, data_end);
           printf (_(" Module pointer (GNU extension)\n"));
           if (ent == (bfd_vma) -1)
             goto got_print_fail;
        }
       printf ("\n");
 
       if (data != NULL && ent < local_end)
         {
           printf (_(" Local entries:\n"));
           printf ("  %*s %10s %*s\n",
                   addr_size * 2, _("Address"), _("Access"),
                   addr_size * 2, _("Initial"));
           while (ent < local_end)
            {
              ent = print_mips_got_entry (data, pltgot, ent, data_end);
               printf ("\n");
              if (ent == (bfd_vma) -1)
                 goto got_print_fail;
             }
          printf ("\n");
         }
 
       if (data != NULL && gotsym < symtabno)
       {
           int sym_width;
 
           printf (_(" Global entries:\n"));
           printf ("  %*s %10s %*s %*s %-7s %3s %s\n",
                   addr_size * 2, _("Address"),
                   _("Access"),
                   addr_size * 2, _("Initial"),
                   addr_size * 2, _("Sym.Val."),
                   _("Type"),
                  /* Note for translators: "Ndx" = abbreviated form of "Index".  */
                   _("Ndx"), _("Name"));
 
           sym_width = (is_32bit_elf ? 80 : ) - 28 - addr_size * 6 - 1;

           for (i = gotsym; i < symtabno; i++)
             {
               ent = print_mips_got_entry (data, pltgot, ent, data_end);
               printf (" ");
 
              if (dynamic_symbols == NULL)
                 printf (_("<no dynamic symbols>"));
               else if (i < num_dynamic_syms)
                 {
                   Elf_Internal_Sym * psym = dynamic_symbols + i;
 
                  print_vma (psym->st_value, LONG_HEX);
                   printf (" %-7s %3s ",
                           get_symbol_type (filedata, ELF_ST_TYPE (psym->st_info)),
                           get_symbol_index_type (filedata, psym->st_shndx));
 
                   if (VALID_DYNAMIC_NAME (psym->st_name))
                     print_symbol (sym_width, GET_DYNAMIC_NAME (psym->st_name));
                   else
                     printf (_("<corrupt: %ld>"), psym->st_name);
                 }
               else
                printf (_("<symbol index %lu exceeds number of dynamic symbols>"),
                         (unsigned long) i);
 
              printf ("\n");
              if (ent == (bfd_vma) -1)
                break;
            }
          printf ("\n");
         }

    got_print_fail:
      if (data)
        free (data);
     }

  if (mips_pltgot != 0 && jmprel != 0 && pltrel != 0 && pltrelsz != 0)
    {
      bfd_vma ent, end;
       size_t offset, rel_offset;
       unsigned long count, i;
       unsigned char * data;
       int addr_size, sym_width;
       Elf_Internal_Rela * rels;
 
       rel_offset = offset_from_vma (filedata, jmprel, pltrelsz);
       if (pltrel == DT_RELA)
         {
           if (!slurp_rela_relocs (filedata, rel_offset, pltrelsz, &rels, &count))
             return FALSE;
         }
       else
        {
          if (!slurp_rel_relocs (filedata, rel_offset, pltrelsz, &rels, &count))
            return FALSE;
         }
 
       ent = mips_pltgot;
       addr_size = (is_32bit_elf ? 4 : 8);
       end = mips_pltgot + (2 + count) * addr_size;

      offset = offset_from_vma (filedata, mips_pltgot, end - mips_pltgot);
       data = (unsigned char *) get_data (NULL, filedata, offset, end - mips_pltgot,
                                         1, _("Procedure Linkage Table data"));
      if (data == NULL)
         return FALSE;
 
       printf ("\nPLT GOT:\n\n");
       printf (_(" Reserved entries:\n"));
       printf (_("  %*s %*s Purpose\n"),
               addr_size * 2, _("Address"), addr_size * 2, _("Initial"));
       ent = print_mips_pltgot_entry (data, mips_pltgot, ent);
       printf (_(" PLT lazy resolver\n"));
       ent = print_mips_pltgot_entry (data, mips_pltgot, ent);
       printf (_(" Module pointer\n"));
       printf ("\n");
 
       printf (_(" Entries:\n"));
       printf ("  %*s %*s %*s %-7s %3s %s\n",
               addr_size * 2, _("Address"),
               addr_size * 2, _("Initial"),
               addr_size * 2, _("Sym.Val."), _("Type"), _("Ndx"), _("Name"));
       sym_width = (is_32bit_elf ? 80 : ) -  - addr_size * 6 - 1;
       for (i = 0; i < count; i++)
         {
           unsigned long idx = get_reloc_symindex (rels[i].r_info);
 
           ent = print_mips_pltgot_entry (data, mips_pltgot, ent);
           printf (" ");
 
           if (idx >= num_dynamic_syms)
             printf (_("<corrupt symbol index: %lu>"), idx);
           else
             {
               Elf_Internal_Sym * psym = dynamic_symbols + idx;
 
               print_vma (psym->st_value, LONG_HEX);
               printf (" %-7s %3s ",
                      get_symbol_type (filedata, ELF_ST_TYPE (psym->st_info)),
                       get_symbol_index_type (filedata, psym->st_shndx));
               if (VALID_DYNAMIC_NAME (psym->st_name))
                 print_symbol (sym_width, GET_DYNAMIC_NAME (psym->st_name));
               else
                 printf (_("<corrupt: %ld>"), psym->st_name);
             }
           printf ("\n");
         }
       printf ("\n");
 
       if (data)
         free (data);
       free (rels);
     }

  return res;
}